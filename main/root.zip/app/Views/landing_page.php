<canvas id="canvas-basic"></canvas>

<div class="container-fluid">
    <div class="row" style="height: 40vh;">
        <div class="col"></div>
    </div>

    <div class="row" style="height: 15vh;">
        <div class="col"></div>

        <div class="col-6 d-flex text-center" style="min-height: 50%; ">
            <span style="font-size: 2.5rem; margin: 0; padding: 0;" id="typed" class="element  m-auto"></span>

        </div>
        
        <div class="col"></div>
    </div>

    <div class="row" style="height: 10vh;">
        <div class="col text-center">
            <div id="more" class="btn btn-outline-dark text-center">Find out More</div>
        </div>
    </div>

    <div class="row" style="height: 35vh;">
        <div class="col"></div>
    </div>
</div>