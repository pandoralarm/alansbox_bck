<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="css/adapts.css">

    <!-- FONTS -->
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Source Sans Pro' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Source Code Pro' rel='stylesheet'>

    <style>
      body {
          font-family: 'Source Sans Pro';font-size: 22px;
      }

      .web {
          font-family: 'Source Code Pro';font-size: 36px;
      }

      .grap {
          font-family: 'Poppins';font-size: 36px;
      }

      #more {
        opacity: 0;
      }
    </style>
    <title>Its Alan's Box!</title>
  </head>
  <body>